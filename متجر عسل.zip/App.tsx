
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Language, Theme, Page, Product, Category, Order, User, DashboardStats, PaymentMethod
} from './types';
import { db } from './services/db';
import { PRODUCTS, SOCIAL_LINKS } from './constants';
import { geminiService } from './services/geminiService';

const translations = {
  ar: {
    storeName: "الغزالي",
    slogan: "أصل النقاء والجودة",
    home: "الرئيسية",
    shop: "تسوق",
    about: "من نحن",
    policy: "سياسة الاسترجاع",
    contact: "تواصل معنا",
    admin: "لوحة التحكم",
    search: "ابحث عن منتج...",
    cart: "سلة المشتريات",
    empty_cart: "السلة فارغة حالياً.. ابدأ التسوق الآن! 🍯",
    total: "الإجمالي",
    subtotal: "المجموع الفرعي",
    addCart: "أضف للسلة",
    buyNow: "اشترِ الآن",
    checkout: "إتمام الطلب",
    confirm_order: "تأكيد الطلب 👑",
    customer_info: "بيانات التوصيل",
    full_name: "الاسم الكامل",
    phone_number: "رقم الهاتف (واتساب)",
    address: "عنوان التوصيل بالتفصيل",
    payment_method: "طريقة الدفع",
    cod: "دفع عند الاستلام",
    vfcash: "فودافون كاش",
    order_success: "تم إرسال طلبك بنجاح! سنتواصل معك قريباً. ✨",
    back_to_cart: "العودة للسلة",
    has_discount: "تفعيل الخصم؟",
    discount_active: "خصم نشط",
    discount_inactive: "بدون خصم",
    yes: "نعم",
    no: "لا",
    success_save: "تم حفظ المنتج بنجاح! 👑",
    success_delete: "تم حذف المنتج بنجاح! 🗑️",
    confirm_delete: "هل أنت متأكد من حذف هذا المنتج؟ لا يمكن التراجع عن هذه الخطوة.",
    discount_type: "نوع الخصم",
    discount_val: "قيمة الخصم",
    final_price: "السعر النهائي",
    percent: "نسبة مئوية (%)",
    fixed: "مبلغ ثابت (ج.م)",
    status: "حالة المنتج",
    active: "نشط (يظهر في المتجر)",
    inactive: "معطل (مخفي)",
    images_count: "الصور المرفوعة",
    add_image: "رفع صور إضافية",
    max_size_error: "حجم الصورة كبير جداً (الأقصى 5 ميجابايت)",
    file_type_error: "نوع الملف غير مدعوم",
    product_details: "تفاصيل المنتج",
    weight_label: "الوزن/الحجم:",
    sku_label: "كود المنتج:",
    stock_status: "الحالة:",
    in_stock: "متوفر",
    out_of_stock: "نفذت الكمية",
    categories: {
      honey: "عسل نحل",
      oils: "زيوت طبيعية",
      halawa: "حلاوة",
      dates: "تمور",
      zamzam: "ماء زمزم",
      candles: "شموع",
      sweeteners: "محليات",
      essential: "زيوت عطرية",
      juices: "عصائر طبيعية",
      packages: "باكجات",
      offers: "عروض",
      other: "منتجات أخرى",
      all: "الكل"
    },
    footer_desc: "نحن في الغزالي نؤمن بأن الطبيعة هي مصدر كل خير، لذا نوفر لكم أجود أنواع العسل والزيوت والمنتجات الطبيعية مباشرة.",
    contact_wa: "تواصل واتساب",
    login_title: "دخول المشرفين",
    email: "البريد الإلكتروني",
    pass: "كلمة المرور",
    login: "دخول",
    revenue: "الإيرادات",
    orders: "الطلبات",
    products: "المنتجات",
    customers: "العملاء",
    cart_analytics: "تحليلات السلة",
    adds: "إضافات",
    sales: "مبيعات",
    ai_studio: "AI Studio",
    transform_btn: "تحويل لصورة احترافية",
    upload_img: "ارفع صورة المنتج",
    processing: "جاري المعالجة الذكية...",
    manage_products: "إدارة المنتجات",
    add_new_product: "إضافة منتج جديد",
    edit_product: "تعديل المنتج",
    save: "حفظ المنتج الآن 👑",
    delete: "حذف",
    cancel: "إلغاء",
    name_ar: "الاسم (بالعربي)",
    name_en: "الاسم (بالإنجليزي)",
    desc_ar: "الوصف (بالعربي)",
    desc_en: "الوصف (بالإنجليزي)",
    price: "السعر حالياً",
    old_price: "السعر الأصلي",
    stock: "الكمية المتاحة",
    sku: "كود المنتج (SKU)",
    weight: "الوزن / الحجم",
    category: "نوع المنتج (القسم)"
  },
  en: {
    storeName: "Al Ghazaly",
    slogan: "Origin of Purity",
    home: "Home",
    shop: "Shop",
    about: "About Us",
    policy: "Returns",
    contact: "Contact",
    admin: "Dashboard",
    search: "Search...",
    cart: "Shopping Cart",
    empty_cart: "Your cart is empty.. Start shopping! 🍯",
    total: "Total",
    subtotal: "Subtotal",
    addCart: "Add",
    buyNow: "Buy Now",
    checkout: "Checkout",
    confirm_order: "Confirm Order 👑",
    customer_info: "Delivery Info",
    full_name: "Full Name",
    phone_number: "Phone (WhatsApp)",
    address: "Detailed Address",
    payment_method: "Payment",
    cod: "Cash on Delivery",
    vfcash: "Vodafone Cash",
    order_success: "Order placed! We will contact you soon. ✨",
    back_to_cart: "Back to Cart",
    has_discount: "Apply Discount?",
    discount_active: "Discount Active",
    discount_inactive: "No Discount",
    yes: "Yes",
    no: "No",
    success_save: "Product saved successfully! 👑",
    success_delete: "Product deleted! 🗑️",
    confirm_delete: "Are you sure you want to delete this product?",
    discount_type: "Discount Type",
    discount_val: "Discount Value",
    final_price: "Final Price",
    percent: "Percentage (%)",
    fixed: "Fixed Amount (EGP)",
    status: "Product Status",
    active: "Active (Visible)",
    inactive: "Inactive (Hidden)",
    images_count: "Images Uploaded",
    add_image: "Add More Images",
    max_size_error: "File size too large (Max 5MB)",
    file_type_error: "Unsupported file type",
    product_details: "Product Details",
    weight_label: "Weight/Size:",
    sku_label: "SKU:",
    stock_status: "Status:",
    in_stock: "In Stock",
    out_of_stock: "Out of Stock",
    categories: {
      honey: "Honey",
      oils: "Oils",
      halawa: "Halawa",
      dates: "Dates",
      zamzam: "Zamzam",
      candles: "Candles",
      sweeteners: "Sweeteners",
      essential: "Essential",
      juices: "Juices",
      packages: "Packages",
      offers: "Offers",
      other: "Other",
      all: "All"
    },
    footer_desc: "At Al Ghazaly, we believe nature is the source of all good. We provide the finest natural products.",
    contact_wa: "WhatsApp",
    login_title: "Admin Login",
    email: "Email",
    pass: "Password",
    login: "Login",
    revenue: "Revenue",
    orders: "Orders",
    products: "Products",
    customers: "Customers",
    cart_analytics: "Analytics",
    adds: "Adds",
    sales: "Sales",
    ai_studio: "AI Studio",
    transform_btn: "Transform Photo",
    upload_img: "Upload Image",
    processing: "Processing...",
    manage_products: "Manage Products",
    add_new_product: "New Product",
    edit_product: "Edit",
    save: "Save Product 👑",
    delete: "Delete",
    cancel: "Cancel",
    name_ar: "Name (AR)",
    name_en: "Name (EN)",
    desc_ar: "Desc (AR)",
    desc_en: "Desc (EN)",
    price: "Current Price",
    old_price: "Original Price",
    stock: "Stock",
    sku: "SKU",
    weight: "Weight",
    category: "Product Type"
  }
};

interface CartItem {
  product: Product;
  quantity: number;
}

interface AdminDashboardProps {
  t: any;
  lang: Language;
  isRTL: boolean;
  setUser: (u: User | null) => void;
  setPage: (p: Page) => void;
  allProducts: Product[];
  setAllProducts: (prods: Product[]) => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ t, lang, isRTL, setUser, setPage, allProducts, setAllProducts }) => {
  const stats = db.getStats();
  const [orders, setOrders] = useState<Order[]>(db.getOrders());
  const [view, setView] = useState<'stats' | 'products' | 'orders' | 'ai_studio'>('stats');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  
  const [isSaving, setIsSaving] = useState(false);
  const [productImages, setProductImages] = useState<string[]>([]);
  const [hasDiscount, setHasDiscount] = useState(false);
  const [discountType, setDiscountType] = useState<'percent' | 'fixed'>('percent');
  const [discountValue, setDiscountValue] = useState<number>(0);
  const [originalPrice, setOriginalPrice] = useState<number>(0);
  const [productStatus, setProductStatus] = useState<'active' | 'inactive'>('active');
  const [isUploading, setIsUploading] = useState(false);
  
  const prodFileInputRef = useRef<HTMLInputElement>(null);
  const [originalImg, setOriginalImg] = useState<string | null>(null);
  const [resultImg, setResultImg] = useState<string | null>(null);
  const [isAILoading, setIsAILoading] = useState(false);
  const aiFileInputRef = useRef<HTMLInputElement>(null);

  const allowedCategories: Category[] = ['honey', 'oils', 'halawa', 'dates', 'zamzam', 'candles', 'other'];

  useEffect(() => {
    if (editingProduct && editingProduct.id) {
      setHasDiscount(!!editingProduct.originalPrice);
      setDiscountType(editingProduct.discountType || 'percent');
      setDiscountValue(editingProduct.discountValue || 0);
      setOriginalPrice(editingProduct.originalPrice || editingProduct.price);
      setProductImages(editingProduct.images || []);
      setProductStatus(editingProduct.status || 'active');
    } else if (editingProduct) {
      setHasDiscount(false);
      setDiscountType('percent');
      setDiscountValue(0);
      setOriginalPrice(0);
      setProductImages([]);
      setProductStatus('active');
    }
  }, [editingProduct]);

  const calculatedFinalPrice = useMemo(() => {
    if (!hasDiscount || !originalPrice) return originalPrice;
    if (discountType === 'percent') {
      return Math.max(0, originalPrice * (1 - discountValue / 100));
    } else {
      return Math.max(0, originalPrice - discountValue);
    }
  }, [hasDiscount, discountType, discountValue, originalPrice]);

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSaving) return;
    setIsSaving(true);
    const form = e.currentTarget as HTMLFormElement;
    const fd = new FormData(form);
    const productData: Product = {
      id: editingProduct?.id || 'p-' + Date.now(),
      name: { ar: fd.get('name_ar') as string, en: (fd.get('name_en') as string) || (fd.get('name_ar') as string) },
      description: { ar: fd.get('desc_ar') as string, en: (fd.get('desc_en') as string) || (fd.get('desc_ar') as string) },
      price: hasDiscount ? calculatedFinalPrice : originalPrice,
      originalPrice: hasDiscount ? originalPrice : undefined,
      discountType: hasDiscount ? discountType : undefined,
      discountValue: hasDiscount ? discountValue : undefined,
      category: fd.get('category') as Category,
      stock: Number(fd.get('stock')),
      images: productImages.length > 0 ? productImages : ['https://via.placeholder.com/400'],
      sku: (fd.get('sku') as string) || 'SKU-' + Date.now(),
      status: productStatus,
      weight: (fd.get('weight') as string) || '1kg',
      createdAt: editingProduct?.createdAt || new Date().toISOString(),
      cartAddCount: editingProduct?.cartAddCount || 0,
      purchaseCount: editingProduct?.purchaseCount || 0
    };
    try {
      const response = await db.saveProduct(productData);
      if (response.success) {
        setAllProducts(db.getProducts());
        alert(t.success_save);
        setEditingProduct(null);
      }
    } catch (err) { alert(isRTL ? "فشل الحفظ" : "Save failed"); } finally { setIsSaving(false); }
  };

  // Fix: Explicitly cast Array.from(files) as File[] to prevent 'unknown' property access errors.
  const handleMultipleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setIsUploading(true);
    const validImages: string[] = [];
    const maxSize = 5 * 1024 * 1024;
    for (const file of Array.from(files) as File[]) {
      if (!file.type.startsWith('image/')) { alert(t.file_type_error); continue; }
      if (file.size > maxSize) { alert(t.max_size_error + `: ${file.name}`); continue; }
      const reader = new FileReader();
      const base64 = await new Promise<string>((resolve) => {
        reader.onload = () => resolve(reader.result as string);
        reader.readAsDataURL(file);
      });
      validImages.push(base64);
    }
    setProductImages(prev => [...prev, ...validImages]);
    setIsUploading(false);
    e.target.value = '';
  };

  const handleAITransform = async () => {
    if (!originalImg) return;
    setIsAILoading(true);
    try {
      const prompt = "Professional studio product photo, clean white background, high-end commercial lighting.";
      const result = await geminiService.transformImage(originalImg, prompt);
      setResultImg(result);
    } catch (err: any) { alert(err?.message || err); } finally { setIsAILoading(false); }
  };

  const handleDeleteProduct = async (id: string) => {
    if (window.confirm(t.confirm_delete)) {
      await db.deleteProduct(id);
      setAllProducts(db.getProducts());
      alert(t.success_delete);
    }
  };

  return (
    <div className="pt-32 pb-20 px-6 max-w-7xl mx-auto animate-in">
      <header className="flex flex-col md:flex-row justify-between items-center mb-12 gap-6 bg-white dark:bg-slate-900 p-8 rounded-[3rem] border-2 border-slate-100 dark:border-slate-800 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-amber-500/10 rounded-2xl flex items-center justify-center text-amber-500 text-2xl"><i className="fa-solid fa-crown"></i></div>
          <div className={isRTL ? 'text-right' : 'text-left'}>
            <h1 className="text-4xl font-black text-slate-900 dark:text-white">{t.admin}</h1>
            <p className="text-amber-500 font-bold uppercase tracking-widest text-[10px]">{t.slogan}</p>
          </div>
        </div>
        <div className="flex gap-2 flex-wrap justify-center">
          <button onClick={() => setView('stats')} className={`px-5 py-3 rounded-2xl font-bold transition-all ${view === 'stats' ? 'bg-amber-500 text-black shadow-lg' : 'bg-slate-100 dark:bg-slate-800 dark:text-slate-200'}`}>{t.revenue}</button>
          <button onClick={() => setView('products')} className={`px-5 py-3 rounded-2xl font-bold transition-all ${view === 'products' ? 'bg-amber-500 text-black shadow-lg' : 'bg-slate-100 dark:bg-slate-800 dark:text-slate-200'}`}>{t.products}</button>
          <button onClick={() => setView('orders')} className={`px-5 py-3 rounded-2xl font-bold transition-all ${view === 'orders' ? 'bg-amber-500 text-black shadow-lg' : 'bg-slate-100 dark:bg-slate-800 dark:text-slate-200'}`}>{t.orders}</button>
          <button onClick={() => setView('ai_studio')} className={`px-5 py-3 rounded-2xl font-bold transition-all ${view === 'ai_studio' ? 'bg-black text-amber-500 border-2 border-amber-500' : 'bg-slate-100 dark:bg-slate-800 dark:text-slate-200'}`}><i className="fa-solid fa-wand-magic-sparkles mr-2"></i> {t.ai_studio}</button>
          <button onClick={() => { db.logout(); setUser(null); setPage('home'); }} className="w-12 h-12 bg-red-50 text-red-500 rounded-2xl flex items-center justify-center hover:bg-red-500 hover:text-white transition-all"><i className="fa-solid fa-power-off"></i></button>
        </div>
      </header>

      {view === 'stats' && (
        <div className="space-y-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { label: t.revenue, val: stats.totalRevenue.toLocaleString() + ' ج.م', icon: 'fa-money-bill-trend-up' },
              { label: t.orders, val: stats.totalOrders, icon: 'fa-box' },
              { label: t.products, val: stats.totalProducts, icon: 'fa-tags' },
              { label: t.customers, val: stats.totalCustomers, icon: 'fa-users' }
            ].map((s, i) => (
              <div key={i} className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 shadow-lg transition-transform hover:scale-105">
                <i className={`fa-solid ${s.icon} text-amber-500 text-xl mb-4`}></i>
                <span className="text-[10px] font-black text-slate-400 block mb-1 uppercase tracking-wider">{s.label}</span>
                <span className="text-3xl font-black text-slate-900 dark:text-white">{s.val}</span>
              </div>
            ))}
          </div>
          <div className="bg-white dark:bg-slate-900 p-10 rounded-[3rem] border border-slate-100 dark:border-slate-800 shadow-lg">
            <h2 className="text-2xl font-black mb-8 dark:text-white flex items-center gap-3"><i className="fa-solid fa-chart-line text-amber-500"></i> {t.cart_analytics}</h2>
            <table className="w-full text-center">
              <thead className="text-slate-400 text-xs uppercase border-b border-slate-100 dark:border-slate-800">
                <tr><th className="p-4">{t.products}</th><th className="p-4">{t.adds}</th><th className="p-4">{t.sales}</th><th>التحويل</th></tr>
              </thead>
              <tbody className="divide-y divide-slate-50 dark:divide-slate-800/50">
                {stats.cartAnalytics.map((a, i) => (
                  <tr key={i} className="dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                    <td className="p-4 font-black">{a.productName}</td>
                    <td className="p-4 text-amber-500 font-bold">{a.adds}</td>
                    <td className="p-4 text-green-500 font-bold">{a.sales}</td>
                    <td className="p-4 font-bold"><span className="px-2 py-1 bg-slate-100 dark:bg-slate-800 rounded-md">{a.adds > 0 ? Math.round((a.sales/a.adds)*100) : 0}%</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {view === 'products' && (
        <div className="space-y-8 animate-in">
           <div className="flex justify-between items-center bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-slate-100 dark:border-slate-800 shadow-md">
             <h2 className="text-2xl font-black dark:text-white">{t.manage_products}</h2>
             <button onClick={() => setEditingProduct({} as any)} className="px-6 py-3 bg-black dark:bg-amber-500 text-white dark:text-black rounded-xl font-black shadow-lg hover:scale-105 transition-all">
               <i className="fa-solid fa-plus mr-2"></i> {t.add_new_product}
             </button>
           </div>
           {editingProduct && (
             <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm animate-in">
               <form onSubmit={handleSaveProduct} className="relative w-full max-w-4xl bg-white dark:bg-slate-900 p-10 rounded-[4rem] shadow-2xl max-h-[90vh] overflow-y-auto space-y-8 scroll-smooth">
                  <div className="flex justify-between items-center border-b dark:border-slate-800 pb-4">
                    <h3 className="text-3xl font-black dark:text-white flex items-center gap-4">
                      <i className="fa-solid fa-box-open text-amber-500"></i>
                      {editingProduct.id ? t.edit_product : t.add_new_product}
                    </h3>
                    <button type="button" onClick={() => setEditingProduct(null)} className="w-10 h-10 bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-red-500 rounded-full transition-all"><i className="fa-solid fa-xmark text-xl"></i></button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                     <div className="space-y-4">
                       <label className="block text-xs font-black text-slate-400 uppercase tracking-widest">{t.category}</label>
                       <select name="category" defaultValue={editingProduct.category} required className="w-full p-4 bg-slate-50 dark:bg-slate-800 dark:text-white rounded-2xl font-bold outline-none border-2 border-transparent focus:border-amber-500 transition-all shadow-inner">
                         <option value="" disabled>{isRTL ? 'اختر القسم' : 'Select Category'}</option>
                         {allowedCategories.map(c => <option key={c} value={c}>{t.categories[c]}</option>)}
                       </select>
                     </div>
                     <div className="space-y-4">
                        <label className="block text-xs font-black text-slate-400 uppercase tracking-widest">{t.images_count} ({productImages.length})</label>
                        <div className="flex flex-wrap gap-4 min-h-[120px] p-6 bg-slate-50 dark:bg-slate-800 rounded-3xl border-2 border-dashed border-slate-200 dark:border-slate-700">
                          {productImages.map((img, i) => (
                            <div key={i} className="relative w-24 h-24 rounded-2xl overflow-hidden group shadow-md border border-white dark:border-slate-700">
                              <img src={img} className="w-full h-full object-cover" />
                              <button type="button" onClick={() => setProductImages(prev => prev.filter((_, idx) => idx !== i))} className="absolute inset-0 bg-red-500/80 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"><i className="fa-solid fa-trash"></i></button>
                            </div>
                          ))}
                          <button type="button" onClick={() => prodFileInputRef.current?.click()} disabled={isUploading} className="w-24 h-24 rounded-2xl bg-white dark:bg-slate-900 border-2 border-dashed border-amber-500/30 flex flex-col items-center justify-center text-amber-500 hover:bg-amber-500/10 transition-all">
                            {isUploading ? <i className="fa-solid fa-circle-notch animate-spin text-2xl"></i> : <><i className="fa-solid fa-plus text-xl mb-1"></i><span className="text-[10px] font-black">{t.add_image}</span></>}
                          </button>
                        </div>
                        <input type="file" ref={prodFileInputRef} onChange={handleMultipleFileChange} className="hidden" accept="image/*" multiple />
                     </div>
                     <div className="space-y-4">
                       <label className="block text-xs font-black text-slate-400 uppercase tracking-widest">{t.name_ar}</label>
                       <input name="name_ar" placeholder={t.name_ar} defaultValue={editingProduct.name?.ar} required className="w-full p-4 bg-slate-50 dark:bg-slate-800 dark:text-white rounded-2xl outline-none border-2 border-transparent focus:border-amber-500 transition-all font-bold" />
                     </div>
                     <div className="space-y-4">
                       <label className="block text-xs font-black text-slate-400 uppercase tracking-widest">{t.name_en}</label>
                       <input name="name_en" placeholder={t.name_en} defaultValue={editingProduct.name?.en} className="w-full p-4 bg-slate-50 dark:bg-slate-800 dark:text-white rounded-2xl outline-none border-2 border-transparent focus:border-amber-500 transition-all font-bold" />
                     </div>
                     <div className="space-y-4 md:col-span-2">
                       <label className="block text-xs font-black text-slate-400 uppercase tracking-widest">{t.desc_ar}</label>
                       <textarea name="desc_ar" placeholder={t.desc_ar} defaultValue={editingProduct.description?.ar} rows={3} required className="w-full p-4 bg-slate-50 dark:bg-slate-800 dark:text-white rounded-2xl outline-none border-2 border-transparent focus:border-amber-500 transition-all font-bold" />
                     </div>
                     <div className="md:col-span-2 p-8 bg-slate-100/50 dark:bg-slate-800/50 rounded-[3rem] space-y-8 border-2 border-slate-200 dark:border-slate-800 shadow-inner">
                       <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                          <span className="font-black dark:text-white text-xl flex items-center gap-3"><i className="fa-solid fa-tags text-amber-500"></i> {t.has_discount}</span>
                          <div className="flex gap-4 p-1 bg-white dark:bg-slate-900 rounded-2xl shadow-sm">
                            <button type="button" onClick={() => setHasDiscount(true)} className={`px-8 py-3 rounded-xl font-black transition-all ${hasDiscount ? 'bg-amber-500 text-black shadow-md' : 'text-slate-400'}`}>{t.yes}</button>
                            <button type="button" onClick={() => setHasDiscount(false)} className={`px-8 py-3 rounded-xl font-black transition-all ${!hasDiscount ? 'bg-slate-500 text-white shadow-md' : 'text-slate-400'}`}>{t.no}</button>
                          </div>
                       </div>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                         <div className="space-y-2">
                           <label className="text-[10px] font-black text-slate-400 uppercase">{hasDiscount ? t.old_price : t.price} (ج.م)</label>
                           <input type="number" value={originalPrice || ''} onChange={(e) => setOriginalPrice(Number(e.target.value))} required className="w-full p-5 bg-white dark:bg-slate-900 dark:text-white rounded-3xl outline-none border-2 border-transparent focus:border-amber-500 transition-all font-black text-2xl" />
                         </div>
                         {hasDiscount && (
                           <>
                             <div className="space-y-2 animate-in slide-in-from-right-full">
                               <label className="text-[10px] font-black text-slate-400 uppercase">{t.discount_type}</label>
                               <select value={discountType} onChange={(e) => setDiscountType(e.target.value as any)} className="w-full p-5 bg-white dark:bg-slate-900 dark:text-white rounded-3xl outline-none border-2 border-transparent focus:border-amber-500 transition-all font-black">
                                 <option value="percent">{t.percent}</option>
                                 <option value="fixed">{t.fixed}</option>
                               </select>
                             </div>
                             <div className="space-y-2 animate-in slide-in-from-right-full">
                               <label className="text-[10px] font-black text-red-400 uppercase">{t.discount_val}</label>
                               <input type="number" value={discountValue || ''} onChange={(e) => setDiscountValue(Number(e.target.value))} className="w-full p-5 bg-white dark:bg-slate-900 dark:text-white rounded-3xl outline-none border-2 border-red-500/20 focus:border-red-500 transition-all font-black text-2xl text-red-500" />
                             </div>
                           </>
                         )}
                       </div>
                       <div className="pt-4 border-t dark:border-slate-800 flex justify-between items-center">
                         <span className="font-black text-slate-500 dark:text-slate-400">{t.final_price}:</span>
                         <span className="text-4xl font-black text-amber-500">{calculatedFinalPrice.toLocaleString()} <small className="text-lg">ج.م</small></span>
                       </div>
                     </div>
                     <div className="space-y-4">
                       <label className="block text-xs font-black text-slate-400 uppercase tracking-widest">{t.status}</label>
                       <div className="flex gap-4 p-1 bg-slate-50 dark:bg-slate-800 rounded-2xl">
                         <button type="button" onClick={() => setProductStatus('active')} className={`flex-1 py-4 rounded-xl font-black transition-all ${productStatus === 'active' ? 'bg-green-500 text-white shadow-md' : 'text-slate-400'}`}>{t.active}</button>
                         <button type="button" onClick={() => setProductStatus('inactive')} className={`flex-1 py-4 rounded-xl font-black transition-all ${productStatus === 'inactive' ? 'bg-red-500 text-white shadow-md' : 'text-slate-400'}`}>{t.inactive}</button>
                       </div>
                     </div>
                     <div className="space-y-4">
                       <label className="block text-xs font-black text-slate-400 uppercase tracking-widest">{t.stock}</label>
                       <input name="stock" type="number" defaultValue={editingProduct.stock} required className="w-full p-4 bg-slate-50 dark:bg-slate-800 dark:text-white rounded-2xl outline-none border-2 border-transparent focus:border-amber-500 transition-all font-bold" />
                     </div>
                     <div className="space-y-4">
                       <label className="block text-xs font-black text-slate-400 uppercase tracking-widest">{t.weight}</label>
                       <input name="weight" defaultValue={editingProduct.weight} className="w-full p-4 bg-slate-50 dark:bg-slate-800 dark:text-white rounded-2xl outline-none border-2 border-transparent focus:border-amber-500 transition-all font-bold" />
                     </div>
                  </div>
                  <div className="flex gap-4 sticky bottom-0 bg-white dark:bg-slate-900 pt-4 pb-2 mt-4 border-t dark:border-slate-800">
                     <button type="submit" disabled={isSaving || isUploading} className="flex-1 py-6 bg-amber-500 text-black rounded-[2rem] font-black text-xl shadow-2xl hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-3 disabled:opacity-50">
                       {isSaving ? <div className="animate-spin h-6 w-6 border-4 border-black border-t-transparent rounded-full"></div> : <i className="fa-solid fa-check-circle"></i>}
                       {t.save}
                     </button>
                     <button type="button" onClick={() => setEditingProduct(null)} className="px-12 py-6 bg-slate-100 dark:bg-slate-800 dark:text-white rounded-[2rem] font-black text-xl hover:bg-slate-200 transition-all">{t.cancel}</button>
                  </div>
               </form>
             </div>
           )}
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
             {allProducts.map(p => (
               <div key={p.id} className={`bg-white dark:bg-slate-900 p-6 rounded-[3rem] border-2 flex gap-6 transition-all hover:border-amber-500 shadow-md group ${p.status === 'inactive' ? 'opacity-60 grayscale' : 'border-slate-100 dark:border-slate-800'}`}>
                 <div className="w-24 h-24 rounded-2xl overflow-hidden bg-slate-50 dark:bg-slate-800 flex-shrink-0 relative">
                   <img src={p.images[0]} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" />
                 </div>
                 <div className="flex-1 text-right flex flex-col justify-between">
                   <div>
                     <h4 className="font-black dark:text-white text-lg line-clamp-1">{p.name[lang]}</h4>
                     <div className="flex items-center gap-2 justify-end">
                       {p.originalPrice && <span className="text-xs text-slate-400 line-through">{p.originalPrice}</span>}
                       <p className="text-amber-500 font-black text-xl">{p.price} <small className="text-[10px]">ج.م</small></p>
                     </div>
                   </div>
                   <div className="flex gap-2 justify-end mt-4">
                     <button onClick={() => setEditingProduct(p)} className="w-10 h-10 bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-amber-500 rounded-xl transition-all shadow-sm"><i className="fa-solid fa-pen text-sm"></i></button>
                     <button onClick={() => handleDeleteProduct(p.id)} className="w-10 h-10 bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-red-500 rounded-xl transition-all shadow-sm"><i className="fa-solid fa-trash text-sm"></i></button>
                   </div>
                 </div>
               </div>
             ))}
           </div>
        </div>
      )}

      {view === 'ai_studio' && (
         <div className="bg-white dark:bg-slate-900 p-12 rounded-[4rem] border-2 border-slate-100 dark:border-slate-800 shadow-2xl text-right animate-in">
            <h2 className="text-4xl font-black dark:text-white mb-2 flex items-center gap-4 justify-end">
              {t.ai_studio}
              <i className="fa-solid fa-wand-magic-sparkles text-amber-500"></i>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div className="space-y-4">
                <div onClick={() => aiFileInputRef.current?.click()} className="aspect-square bg-slate-50 dark:bg-slate-800 rounded-[3rem] border-2 border-dashed border-slate-200 dark:border-slate-700 flex items-center justify-center overflow-hidden cursor-pointer hover:border-amber-500 shadow-inner">
                  {originalImg ? <img src={originalImg} className="w-full h-full object-contain" /> : <i className="fa-solid fa-cloud-arrow-up text-5xl text-slate-200"></i>}
                </div>
                <input type="file" ref={aiFileInputRef} onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    const reader = new FileReader();
                    reader.onload = () => setOriginalImg(reader.result as string);
                    reader.readAsDataURL(file);
                  }
                }} className="hidden" accept="image/*" />
              </div>
              <div className="space-y-4">
                <div className="aspect-square bg-slate-50 dark:bg-slate-800 rounded-[3rem] border-2 border-dashed border-amber-500/20 flex items-center justify-center overflow-hidden shadow-inner">
                  {resultImg ? <img src={resultImg} className="w-full h-full object-contain" /> : (isAILoading ? <div className="animate-spin w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full mx-auto"></div> : <i className="fa-solid fa-sparkles text-6xl text-amber-500/10"></i>)}
                </div>
                <button onClick={handleAITransform} disabled={!originalImg || isAILoading} className="w-full py-5 bg-amber-500 text-black rounded-2xl font-black shadow-xl disabled:opacity-50 transition-all hover:scale-105 active:scale-95">{isAILoading ? t.processing : t.transform_btn}</button>
              </div>
            </div>
         </div>
      )}

      {view === 'orders' && (
         <div className="space-y-6 animate-in">
           {orders.map(o => (
             <div key={o.id} className="bg-white dark:bg-slate-900 p-8 rounded-[3.5rem] border border-slate-100 dark:border-slate-800 shadow-xl flex flex-col md:flex-row justify-between items-center gap-8 group">
               <div className="text-right flex-1 w-full">
                 <h3 className="text-2xl font-black dark:text-white">{o.customerName}</h3>
                 <p className="text-amber-500 font-bold mb-4">{o.phone}</p>
                 <p className="text-slate-500 text-sm font-bold bg-slate-50 dark:bg-slate-800/50 p-3 rounded-2xl">{o.address}</p>
                 <div className="mt-4 flex gap-2 flex-wrap justify-end">
                   {o.items.map((it, idx) => <span key={idx} className="px-3 py-1 bg-white dark:bg-slate-800 rounded-xl text-xs font-black border">{it.name} <span className="text-amber-500 mx-1">×{it.quantity}</span></span>)}
                 </div>
               </div>
               <div className="flex flex-col md:flex-row items-center gap-8 w-full md:w-auto">
                 <span className="text-3xl font-black text-amber-500">{o.totalPrice} <small className="text-xs">ج.م</small></span>
                 <select value={o.status} onChange={(e) => { db.updateOrderStatus(o.id, e.target.value as any); setOrders(db.getOrders()); }} className="p-4 bg-slate-100 dark:bg-slate-800 dark:text-white rounded-[1.5rem] font-black outline-none shadow-md">
                   <option value="new">جديد</option>
                   <option value="confirmed">مؤكد</option>
                   <option value="shipped">جاري الشحن</option>
                   <option value="delivered">تم التوصيل</option>
                   <option value="cancelled">ملغي</option>
                 </select>
               </div>
             </div>
           ))}
         </div>
      )}
    </div>
  );
};

const ProductModal: React.FC<{ product: Product; onClose: () => void; t: any; lang: Language; isRTL: boolean; onAdd: (p: Product) => void }> = ({ product, onClose, t, lang, isRTL, onAdd }) => {
  const [activeImage, setActiveImage] = useState(product.images[0]);
  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 md:p-10 bg-black/80 backdrop-blur-md animate-in">
      <div className="relative w-full max-w-6xl bg-white dark:bg-slate-900 rounded-[3rem] md:rounded-[5rem] shadow-2xl flex flex-col lg:flex-row overflow-hidden max-h-[90vh]">
        <button onClick={onClose} className="absolute top-6 right-6 z-[210] w-12 h-12 bg-white/20 dark:bg-black/20 hover:bg-red-500 text-white rounded-full flex items-center justify-center transition-all"><i className="fa-solid fa-xmark text-xl"></i></button>
        <div className="w-full lg:w-1/2 p-4 md:p-10 flex flex-col gap-6 bg-slate-50 dark:bg-slate-950/50">
          <div className="aspect-square w-full rounded-[2rem] md:rounded-[4rem] overflow-hidden bg-white dark:bg-slate-800 shadow-inner">
             <img src={activeImage} className="w-full h-full object-contain" alt="" />
          </div>
          <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
            {product.images.map((img, i) => (
              <button key={i} onClick={() => setActiveImage(img)} className={`flex-shrink-0 w-20 h-20 md:w-28 md:h-28 rounded-2xl overflow-hidden border-4 transition-all ${activeImage === img ? 'border-amber-500 scale-105' : 'border-transparent opacity-60'}`}>
                <img src={img} className="w-full h-full object-cover" alt="" />
              </button>
            ))}
          </div>
        </div>
        <div className={`w-full lg:w-1/2 p-8 md:p-16 overflow-y-auto ${isRTL ? 'text-right' : 'text-left'}`}>
          <div className="mb-8">
            <span className="inline-block px-4 py-1 bg-amber-500/10 text-amber-500 rounded-full text-[10px] font-black uppercase mb-4">{t.categories[product.category]}</span>
            <h2 className="text-4xl font-black text-slate-900 dark:text-white mb-6 leading-tight">{product.name[lang]}</h2>
            <div className="flex items-center gap-4 flex-wrap">
              <span className="text-5xl font-black text-amber-500">{product.price.toLocaleString()} <small className="text-xl">ج.م</small></span>
              {product.originalPrice && <span className="text-2xl text-slate-400 line-through font-bold">{product.originalPrice.toLocaleString()}</span>}
            </div>
          </div>
          <div className="space-y-10">
            <div className="p-8 bg-slate-50 dark:bg-slate-800/50 rounded-[3rem] border dark:border-slate-800">
               <p className="text-slate-600 dark:text-slate-300 font-bold leading-relaxed text-lg mb-8">{product.description[lang]}</p>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm font-bold">
                 <div className="flex justify-between"><span className="text-slate-400">{t.weight_label}</span><span className="dark:text-white">{product.weight}</span></div>
                 <div className="flex justify-between"><span className="text-slate-400">{t.sku_label}</span><span className="dark:text-white">{product.sku}</span></div>
               </div>
            </div>
            <div className="flex flex-col md:flex-row gap-4">
               <button onClick={() => { onAdd(product); onClose(); }} className="flex-1 py-6 bg-black dark:bg-amber-500 text-amber-500 dark:text-black rounded-[2rem] font-black text-xl shadow-2xl hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-4"><i className="fa-solid fa-cart-shopping"></i>{t.addCart}</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const CartDrawer: React.FC<{ 
  isOpen: boolean; 
  onClose: () => void; 
  cartItems: CartItem[]; 
  t: any; 
  lang: Language; 
  isRTL: boolean;
  onUpdateQty: (pid: string, delta: number) => void;
  onRemove: (pid: string) => void;
  onPlaceOrder: (details: {name: string, phone: string, address: string, payment: PaymentMethod}) => void;
}> = ({ isOpen, onClose, cartItems, t, lang, isRTL, onUpdateQty, onRemove, onPlaceOrder }) => {
  const [step, setStep] = useState<'list' | 'checkout' | 'success'>('list');
  const totalPrice = cartItems.reduce((acc, item) => acc + (item.product.price * item.quantity), 0);

  const [formData, setFormData] = useState({ name: '', phone: '', address: '', payment: 'cod' as PaymentMethod });

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[300] flex justify-end animate-in">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose}></div>
      <div className={`relative w-full max-w-md bg-white dark:bg-slate-900 h-full shadow-2xl flex flex-col p-8 transition-transform duration-500 ${isOpen ? 'translate-x-0' : (isRTL ? 'translate-x-full' : '-translate-x-full')}`}>
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-black text-slate-900 dark:text-white flex items-center gap-3"><i className="fa-solid fa-cart-shopping text-amber-500"></i> {t.cart}</h2>
          <button onClick={onClose} className="w-10 h-10 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center"><i className="fa-solid fa-xmark"></i></button>
        </div>

        {step === 'list' && (
          <>
            <div className="flex-1 overflow-y-auto space-y-4 pr-2">
              {cartItems.map((item) => (
                <div key={item.product.id} className="flex gap-4 bg-slate-50 dark:bg-slate-800 p-4 rounded-3xl border dark:border-slate-700">
                  <img src={item.product.images[0]} className="w-20 h-20 rounded-2xl object-cover" />
                  <div className="flex-1 text-right">
                    <h4 className="font-black dark:text-white line-clamp-1">{item.product.name[lang]}</h4>
                    <p className="text-amber-500 font-bold">{item.product.price} ج.م</p>
                    <div className="flex items-center gap-3 mt-2 justify-end">
                      <button onClick={() => onUpdateQty(item.product.id, -1)} className="w-8 h-8 bg-white dark:bg-slate-700 rounded-lg flex items-center justify-center shadow-sm"><i className="fa-solid fa-minus text-xs"></i></button>
                      <span className="font-black dark:text-white">{item.quantity}</span>
                      <button onClick={() => onUpdateQty(item.product.id, 1)} className="w-8 h-8 bg-white dark:bg-slate-700 rounded-lg flex items-center justify-center shadow-sm"><i className="fa-solid fa-plus text-xs"></i></button>
                    </div>
                  </div>
                  <button onClick={() => onRemove(item.product.id)} className="text-slate-400 hover:text-red-500 self-center"><i className="fa-solid fa-trash"></i></button>
                </div>
              ))}
              {cartItems.length === 0 && <div className="text-center py-20 text-slate-400 font-bold">{t.empty_cart}</div>}
            </div>
            {cartItems.length > 0 && (
              <div className="mt-8 p-8 bg-slate-100 dark:bg-slate-800 rounded-[2.5rem] space-y-6">
                <div className="flex justify-between items-center font-black">
                  <span className="text-slate-500">{t.total}:</span>
                  <span className="text-2xl text-amber-500">{totalPrice.toLocaleString()} ج.م</span>
                </div>
                <button onClick={() => setStep('checkout')} className="w-full py-5 bg-black dark:bg-amber-500 text-amber-500 dark:text-black rounded-2xl font-black text-xl shadow-xl hover:scale-[1.02] active:scale-95 transition-all">{t.checkout}</button>
              </div>
            )}
          </>
        )}

        {step === 'checkout' && (
          <div className="flex-1 overflow-y-auto space-y-6">
            <h3 className="text-xl font-black dark:text-white border-b pb-4">{t.customer_info}</h3>
            <div className="space-y-4">
               <div><label className="text-xs font-black text-slate-400 uppercase mb-2 block">{t.full_name}</label><input value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} className="w-full p-4 bg-slate-50 dark:bg-slate-800 dark:text-white rounded-2xl outline-none border-2 border-transparent focus:border-amber-500 transition-all font-bold" /></div>
               <div><label className="text-xs font-black text-slate-400 uppercase mb-2 block">{t.phone_number}</label><input value={formData.phone} onChange={(e) => setFormData({...formData, phone: e.target.value})} placeholder="010XXXXXXXX" className="w-full p-4 bg-slate-50 dark:bg-slate-800 dark:text-white rounded-2xl outline-none border-2 border-transparent focus:border-amber-500 transition-all font-bold" /></div>
               <div><label className="text-xs font-black text-slate-400 uppercase mb-2 block">{t.address}</label><textarea value={formData.address} onChange={(e) => setFormData({...formData, address: e.target.value})} className="w-full p-4 bg-slate-50 dark:bg-slate-800 dark:text-white rounded-2xl outline-none border-2 border-transparent focus:border-amber-500 transition-all font-bold" rows={3} /></div>
               <div>
                  <label className="text-xs font-black text-slate-400 uppercase mb-2 block">{t.payment_method}</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button onClick={() => setFormData({...formData, payment: 'cod'})} className={`p-4 rounded-xl border-2 font-black text-xs transition-all ${formData.payment === 'cod' ? 'border-amber-500 bg-amber-500/10 text-amber-500' : 'border-slate-100 dark:border-slate-800 dark:text-white'}`}>{t.cod}</button>
                    <button onClick={() => setFormData({...formData, payment: 'vodafone_cash'})} className={`p-4 rounded-xl border-2 font-black text-xs transition-all ${formData.payment === 'vodafone_cash' ? 'border-amber-500 bg-amber-500/10 text-amber-500' : 'border-slate-100 dark:border-slate-800 dark:text-white'}`}>{t.vfcash}</button>
                  </div>
               </div>
            </div>
            <div className="pt-6">
              <button onClick={() => { if(!formData.name || !formData.phone || !formData.address) {alert('يرجى ملء كافة البيانات'); return;} onPlaceOrder(formData); setStep('success'); }} className="w-full py-5 bg-amber-500 text-black rounded-2xl font-black text-xl shadow-xl hover:scale-105 transition-all">{t.confirm_order}</button>
              <button onClick={() => setStep('list')} className="w-full py-4 text-slate-400 font-bold mt-2 underline">{t.back_to_cart}</button>
            </div>
          </div>
        )}

        {step === 'success' && (
          <div className="flex-1 flex flex-col items-center justify-center text-center space-y-6">
            <div className="w-24 h-24 bg-green-500 text-white rounded-full flex items-center justify-center text-4xl shadow-xl animate-bounce"><i className="fa-solid fa-check"></i></div>
            <h3 className="text-2xl font-black dark:text-white">{t.order_success}</h3>
            <button onClick={() => { onClose(); setStep('list'); }} className="px-10 py-4 bg-black dark:bg-amber-500 text-amber-500 dark:text-black rounded-xl font-black shadow-lg">{t.home}</button>
          </div>
        )}
      </div>
    </div>
  );
}

const App: React.FC = () => {
  const [lang, setLang] = useState<Language>('ar');
  const [theme, setTheme] = useState<Theme>('light');
  const [page, setPage] = useState<Page>('home');
  const [user, setUser] = useState<User | null>(null);
  const [isNavOpen, setIsNavOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCat, setSelectedCat] = useState<Category | 'all'>('all');
  const [allProducts, setAllProducts] = useState<Product[]>([]);
  const [activeProduct, setActiveProduct] = useState<Product | null>(null);

  useEffect(() => {
    const prods = db.getProducts();
    if (prods.length === 0) {
      PRODUCTS.forEach(p => db.saveProduct(p));
      setAllProducts(db.getProducts());
    } else {
      setAllProducts(prods);
    }
    const session = db.getSession();
    if (session) setUser(session);
    const savedLang = localStorage.getItem('gh_lang') as Language;
    if (savedLang) setLang(savedLang);
    const savedTheme = localStorage.getItem('gh_theme') as Theme;
    if (savedTheme) {
      setTheme(savedTheme);
      if (savedTheme === 'dark') document.documentElement.classList.add('dark');
    }
  }, []);

  const t = translations[lang];
  const isRTL = lang === 'ar';

  const filteredProducts = useMemo(() => {
    return allProducts.filter(p => {
      if (user?.role !== 'super_admin' && p.status === 'inactive') return false;
      const matchCat = selectedCat === 'all' || p.category === selectedCat;
      const matchSearch = p.name[lang].toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.description[lang].toLowerCase().includes(searchQuery.toLowerCase());
      return matchCat && matchSearch;
    });
  }, [searchQuery, selectedCat, lang, allProducts, user]);

  const handleAddToCart = (p: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === p.id);
      if (existing) {
        return prev.map(item => item.product.id === p.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { product: p, quantity: 1 }];
    });
    db.trackAddToCart(p.id);
    setIsCartOpen(true);
  };

  const handleUpdateQty = (pid: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.product.id === pid) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const handleRemoveFromCart = (pid: string) => {
    setCart(prev => prev.filter(item => item.product.id !== pid));
  };

  const handlePlaceOrder = (details: {name: string, phone: string, address: string, payment: PaymentMethod}) => {
    const totalPrice = cart.reduce((acc, item) => acc + (item.product.price * item.quantity), 0);
    const newOrder: Order = {
      id: 'ORD-' + Math.random().toString(36).substr(2, 5).toUpperCase(),
      customerName: details.name,
      phone: details.phone,
      address: details.address,
      paymentMethod: details.payment,
      totalPrice,
      status: 'new',
      date: new Date().toLocaleString('ar-EG'),
      items: cart.map(it => ({
        productId: it.product.id,
        name: it.product.name.ar,
        quantity: it.quantity,
        price: it.product.price
      }))
    };
    db.createOrder(newOrder);
    setCart([]);
  };

  return (
    <div className={`min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col font-cairo ${isRTL ? 'rtl' : 'ltr'} transition-colors duration-500`}>
      {/* Navbar */}
      <nav className="fixed top-0 w-full bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl border-b border-slate-200 dark:border-slate-800 z-50 h-20 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 h-full flex items-center justify-between">
          <div className="flex items-center gap-3">
             <button onClick={() => user ? setPage('admin_dashboard') : setPage('admin_login')} className="w-11 h-11 bg-amber-500/10 text-amber-500 rounded-2xl flex items-center justify-center hover:bg-amber-500 hover:text-black transition-all shadow-sm border border-amber-500/20 group">
               <i className="fa-solid fa-crown text-xl group-hover:rotate-12 transition-transform"></i>
             </button>
             <button onClick={() => setIsNavOpen(true)} className="w-10 h-10 text-xl dark:text-slate-200 hover:text-amber-500 transition-colors"><i className="fa-solid fa-bars-staggered"></i></button>
          </div>
          <div className="flex items-center gap-2 cursor-pointer group" onClick={() => setPage('home')}>
            <div className="w-12 h-12 bg-black dark:bg-amber-500 text-amber-500 dark:text-black rounded-2xl flex items-center justify-center text-2xl shadow-xl transition-transform group-hover:rotate-12"><i className="fa-solid fa-bee"></i></div>
            <div className={`hidden sm:block ${isRTL ? 'text-right' : 'text-left'}`}>
              <h1 className="text-2xl font-black text-slate-900 dark:text-white leading-none group-hover:text-amber-500">{t.storeName}</h1>
              <p className="text-[10px] text-amber-500 font-bold tracking-widest uppercase">{t.slogan}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button onClick={() => { const nl = lang === 'ar' ? 'en' : 'ar'; setLang(nl); localStorage.setItem('gh_lang', nl); }} className="px-3 py-1 bg-slate-100 dark:bg-slate-800 dark:text-slate-300 rounded-lg text-xs font-black hover:bg-amber-500 hover:text-black transition-all">{lang === 'ar' ? 'EN' : 'عربي'}</button>
            <button onClick={() => { const nt = theme === 'light' ? 'dark' : 'light'; setTheme(nt); localStorage.setItem('gh_theme', nt); document.documentElement.classList.toggle('dark'); }} className="w-10 h-10 rounded-full dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all flex items-center justify-center"><i className={`fa-solid ${theme === 'light' ? 'fa-moon' : 'fa-sun'}`}></i></button>
            <div className="relative">
               <button onClick={() => setIsCartOpen(true)} className="w-10 h-10 bg-black dark:bg-amber-500 text-amber-500 dark:text-black rounded-full flex items-center justify-center shadow-lg transition-transform hover:scale-110"><i className="fa-solid fa-cart-shopping"></i></button>
               {cart.length > 0 && <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[8px] w-4 h-4 rounded-full flex items-center justify-center font-black animate-pulse shadow-md border-2 border-white dark:border-slate-900">{cart.reduce((a, b) => a + b.quantity, 0)}</span>}
            </div>
          </div>
        </div>
      </nav>

      {/* Sidebar Categories */}
      <div className={`fixed inset-0 z-[100] ${isNavOpen ? 'visible' : 'invisible'} transition-all`}>
        <div className={`absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity ${isNavOpen ? 'opacity-100' : 'opacity-0'}`} onClick={() => setIsNavOpen(false)}></div>
        <div className={`absolute top-0 h-full w-80 bg-white dark:bg-slate-900 border-x border-slate-200 dark:border-slate-800 transition-transform duration-500 ${isRTL ? (isNavOpen ? 'right-0 translate-x-0' : 'right-0 translate-x-full') : (isNavOpen ? 'left-0 translate-x-0' : 'left-0 -translate-x-full')} p-8 shadow-2xl overflow-y-auto`}>
          <div className="flex justify-between items-center mb-10">
            <h2 className="text-3xl font-black text-amber-500">{t.categories.all}</h2>
            <button onClick={() => setIsNavOpen(false)} className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-red-500 transition-colors"><i className="fa-solid fa-xmark text-2xl"></i></button>
          </div>
          <div className="space-y-4">
            {Object.entries(t.categories).map(([key, label]) => (
              <button key={key} onClick={() => { setSelectedCat(key as any); setPage('shop'); setIsNavOpen(false); }} className={`w-full p-4 rounded-2xl font-black flex items-center gap-4 transition-all ${selectedCat === key ? 'bg-amber-500 text-black shadow-lg scale-105' : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200'}`}>
                <i className="fa-solid fa-circle text-[8px] opacity-40"></i> {label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <CartDrawer 
        isOpen={isCartOpen} 
        onClose={() => setIsCartOpen(false)} 
        cartItems={cart} 
        t={t} 
        lang={lang} 
        isRTL={isRTL}
        onUpdateQty={handleUpdateQty}
        onRemove={handleRemoveFromCart}
        onPlaceOrder={handlePlaceOrder}
      />

      <main className="flex-1">
        {page === 'home' && (
          <div className="pt-64 pb-32 text-center animate-in relative overflow-hidden">
             <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full opacity-10 pointer-events-none -z-10 bg-[radial-gradient(circle_at_center,_#F5B301_0%,_transparent_70%)]"></div>
             <div className="max-w-4xl mx-auto px-6 relative z-10">
               <span className="inline-block px-6 py-2 bg-amber-500 text-black font-black text-xs uppercase tracking-[5px] rounded-full mb-8 shadow-xl animate-bounce">Premium Nature</span>
               <h1 className="text-6xl md:text-8xl font-black text-slate-900 dark:text-white mb-8 leading-tight">
                 {t.home === "الرئيسية" ? "مرحباً بكم في" : "Welcome to"} <span className="text-amber-500">{t.storeName}</span>
               </h1>
               <p className="text-xl md:text-2xl text-slate-500 dark:text-slate-400 font-bold mb-12 leading-relaxed max-w-2xl mx-auto">{t.footer_desc}</p>
               <div className="flex justify-center gap-6">
                 <button onClick={() => setPage('shop')} className="px-14 py-6 bg-black dark:bg-amber-500 text-white dark:text-black font-black text-2xl rounded-[2.5rem] shadow-2xl hover:scale-105 active:scale-95 transition-all">{t.shop}</button>
               </div>
             </div>
          </div>
        )}

        {page === 'shop' && (
          <div className="pt-32 pb-24 px-6 max-w-7xl mx-auto animate-in">
             <header className="flex justify-between items-center mb-16 flex-wrap gap-8 bg-white dark:bg-slate-900 p-8 rounded-[3rem] border-2 border-slate-50 dark:border-slate-800 shadow-sm">
               <div className="flex items-center gap-4">
                 <div className="w-2 h-12 bg-amber-500 rounded-full"></div>
                 <h2 className="text-5xl font-black text-slate-900 dark:text-white">{t.categories[selectedCat as keyof typeof t.categories] || t.categories.all}</h2>
               </div>
               <div className="relative w-full md:w-auto">
                 <input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder={t.search} className="w-full md:w-80 p-5 px-14 bg-slate-50 dark:bg-slate-800 border border-transparent dark:border-slate-700 rounded-3xl outline-none font-bold dark:text-white shadow-inner transition-all focus:ring-4 ring-amber-500/10 focus:border-amber-500" />
                 <i className="fa-solid fa-search absolute top-1/2 right-6 -translate-y-1/2 text-slate-400"></i>
               </div>
             </header>

             <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-12">
                {filteredProducts.map(p => (
                  <div key={p.id} onClick={() => setActiveProduct(p)} className="cursor-pointer bg-white dark:bg-slate-900 rounded-[4rem] border-2 border-slate-100 dark:border-slate-800 overflow-hidden group hover:border-amber-500/50 hover:shadow-[0_20px_50px_rgba(245,179,1,0.15)] transition-all duration-700 flex flex-col shadow-lg hover:-translate-y-2">
                     <div className="aspect-[4/5] relative overflow-hidden bg-slate-50 dark:bg-slate-800">
                        <img src={p.images[0]} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" alt="" />
                        {p.originalPrice && <span className="absolute top-8 left-8 px-5 py-2 bg-red-500 text-white rounded-3xl font-black text-[12px] shadow-lg animate-pulse border-2 border-white/20">خصم {Math.round((1 - p.price / p.originalPrice) * 100)}%</span>}
                        <div className={`absolute top-8 ${isRTL ? 'right-8' : 'left-8'}`}>
                           <span className="px-5 py-2 bg-black/80 text-amber-500 backdrop-blur-xl rounded-3xl font-black text-[12px] uppercase tracking-widest border border-white/10 shadow-lg">{t.categories[p.category as keyof typeof t.categories]}</span>
                        </div>
                     </div>
                     <div className="p-10 flex-1 flex flex-col text-right">
                        <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-4 group-hover:text-amber-500 transition-colors">{p.name[lang]}</h3>
                        <p className="text-slate-500 dark:text-slate-400 font-bold text-sm mb-10 line-clamp-2 h-12 leading-relaxed">{p.description[lang]}</p>
                        <div className="mt-auto flex justify-between items-center flex-row-reverse gap-4">
                           <div className="text-right">
                             <span className="text-4xl font-black text-slate-900 dark:text-white">{p.price}</span>
                             <span className="text-sm font-black text-amber-500 mx-2">ج.م</span>
                           </div>
                           <button onClick={(e) => { e.stopPropagation(); handleAddToCart(p); }} className="w-16 h-16 bg-black dark:bg-amber-500 text-amber-500 dark:text-black rounded-[1.5rem] flex items-center justify-center shadow-2xl hover:scale-110 active:scale-95 transition-all group/btn"><i className="fa-solid fa-cart-plus text-2xl group-hover/btn:rotate-12"></i></button>
                        </div>
                     </div>
                  </div>
                ))}
             </div>
          </div>
        )}

        {page === 'admin_login' && (
          <div className="pt-44 flex justify-center px-6 min-h-[80vh] animate-in">
            <div className="w-full max-w-md bg-white dark:bg-slate-900 p-12 rounded-[4.5rem] border-2 border-slate-100 dark:border-slate-800 shadow-2xl h-fit">
               <div className="text-center mb-12">
                 <div className="w-24 h-24 bg-black dark:bg-amber-500 text-amber-500 dark:text-black rounded-[2rem] flex items-center justify-center text-4xl mx-auto mb-8 shadow-2xl transition-transform hover:scale-110 hover:rotate-6"><i className="fa-solid fa-crown"></i></div>
                 <h2 className="text-4xl font-black text-slate-900 dark:text-white">{t.login_title}</h2>
               </div>
               <form onSubmit={(e) => { e.preventDefault(); const fd = new FormData(e.currentTarget as HTMLFormElement); const u = db.login(fd.get('email') as string, fd.get('pass') as string); if (u) { setUser(u); setPage('admin_dashboard'); } else alert('بيانات الدخول غير صحيحة'); }} className="space-y-6">
                 <input name="email" type="email" placeholder={t.email} defaultValue="mosadghazali123@gmail.com" required className="w-full p-6 bg-slate-50 dark:bg-slate-800 dark:text-white rounded-[2rem] outline-none font-bold border-2 border-transparent focus:border-amber-500 transition-all shadow-inner" />
                 <input name="pass" type="password" placeholder={t.pass} defaultValue="mosadghazali" required className="w-full p-6 bg-slate-50 dark:bg-slate-800 dark:text-white rounded-[2rem] outline-none font-bold border-2 border-transparent focus:border-amber-500 transition-all shadow-inner" />
                 <button className="w-full py-6 bg-black dark:bg-amber-500 text-amber-500 dark:text-black rounded-[2rem] font-black text-2xl hover:scale-[1.02] active:scale-95 transition-all shadow-2xl mt-4">
                   <i className="fa-solid fa-unlock-keyhole mr-3"></i>
                   {t.login}
                 </button>
               </form>
            </div>
          </div>
        )}

        {page === 'admin_dashboard' && (
          <AdminDashboard 
            t={t} 
            lang={lang} 
            isRTL={isRTL} 
            setUser={setUser} 
            setPage={setPage} 
            allProducts={allProducts}
            setAllProducts={setAllProducts}
          />
        )}
      </main>

      {activeProduct && (
        <ProductModal 
          product={activeProduct} 
          onClose={() => setActiveProduct(null)} 
          t={t} 
          lang={lang} 
          isRTL={isRTL} 
          onAdd={handleAddToCart}
        />
      )}

      {/* Footer */}
      <footer className="py-24 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 transition-all">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-20 text-center md:text-right">
          <div className="md:col-span-2">
            <h2 className="text-6xl font-black text-amber-500 mb-10 flex items-center justify-center md:justify-start gap-4">
              {t.storeName}
              <i className="fa-solid fa-bee animate-bounce text-4xl"></i>
            </h2>
            <p className="text-slate-500 dark:text-slate-400 font-bold text-xl leading-relaxed max-w-lg mx-auto md:mx-0">{t.footer_desc}</p>
          </div>
          <div>
            <h4 className="font-black text-2xl mb-10 text-slate-900 dark:text-white relative inline-block">الأقسام<span className="absolute -bottom-2 right-0 w-10 h-1 bg-amber-500 rounded-full"></span></h4>
            <ul className="space-y-5 font-black text-lg text-slate-500 dark:text-slate-400">
               {['honey', 'oils', 'dates', 'all'].map(c => <li key={c}><button onClick={() => { setSelectedCat(c as any); setPage('shop'); window.scrollTo(0,0); }} className="hover:text-amber-500 transition-all hover:translate-x-2 inline-block">{t.categories[c as keyof typeof t.categories]}</button></li>)}
            </ul>
          </div>
          <div className="flex flex-col items-center md:items-start">
            <h4 className="font-black text-2xl mb-10 text-slate-900 dark:text-white relative inline-block">تواصل معنا<span className="absolute -bottom-2 left-0 w-10 h-1 bg-amber-500 rounded-full md:left-auto md:right-0"></span></h4>
            <a href="https://wa.me/201027731829" className="inline-flex items-center gap-4 px-10 py-5 bg-green-500 text-white rounded-[2.5rem] font-black text-xl shadow-2xl hover:scale-105 active:scale-95 transition-all mb-10 border-4 border-white/10"><i className="fa-brands fa-whatsapp text-3xl"></i>{t.contact_wa}</a>
            <div className="flex gap-8">
               <a href={SOCIAL_LINKS.facebook} className="w-14 h-14 bg-slate-100 dark:bg-slate-800 rounded-2xl flex items-center justify-center text-slate-500 hover:bg-amber-500 hover:text-black transition-all shadow-md group"><i className="fab fa-facebook-f text-xl group-hover:rotate-12"></i></a>
               <a href={SOCIAL_LINKS.instagram} className="w-14 h-14 bg-slate-100 dark:bg-slate-800 rounded-2xl flex items-center justify-center text-slate-500 hover:bg-amber-500 hover:text-black transition-all shadow-md group"><i className="fab fa-instagram text-xl group-hover:rotate-12"></i></a>
            </div>
          </div>
        </div>
        <div className="text-center mt-32 pt-12 border-t border-slate-100 dark:border-slate-800/50 text-slate-400 text-[12px] font-black uppercase tracking-[10px]">Al Ghazaly Premium Nature &copy; 2024</div>
      </footer>
    </div>
  );
};

export default App;
