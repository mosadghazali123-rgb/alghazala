
import { Product, Review } from './types';

export const SOCIAL_LINKS = {
  facebook: "https://www.facebook.com/share/1HArRNEWAV/",
  instagram: "https://www.instagram.com/the_honey_off_algazala?igsh=aWE1Z3ZqYjk4d2Zj"
};

export const PRODUCTS: Product[] = [
  { 
    id: 'h1', 
    name: { ar: 'عسل سدر جبلي فاخر', en: 'Premium Mountain Sidr Honey' }, 
    category: 'honey', 
    price: 950, 
    images: ['https://images.unsplash.com/photo-1589733901241-5d5297e7dec2?q=80&w=800'], 
    description: { ar: 'عسل سدر طبيعي خام مستخلص من جبال اليمن، يتميز بقوامه الكثيف.', en: 'Natural raw Sidr honey extracted from Yemen mountains, thick texture.' }, 
    weight: '1kg', 
    stock: 50, 
    sku: 'HNY-SDR-01', 
    status: 'active', 
    createdAt: new Date().toISOString(),
    cartAddCount: 0,
    purchaseCount: 0
  },
  { 
    id: 'o1', 
    name: { ar: 'زيت زيتون بكر ممتاز', en: 'Extra Virgin Olive Oil' }, 
    category: 'oils', 
    price: 480, 
    images: ['https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?q=80&w=800'], 
    description: { ar: 'عصرة أولى على البارد من أجود أنواع الزيتون السيناوي.', en: 'First cold press from the finest Sinai olives.' }, 
    weight: '1L', 
    stock: 100, 
    sku: 'OIL-OLV-01', 
    status: 'active', 
    createdAt: new Date().toISOString(),
    cartAddCount: 0,
    purchaseCount: 0
  }
];

export const REVIEWS: Review[] = [
  { id: 'rev1', productId: 'h1', userName: 'محمود الصاوي', location: 'القاهرة', rating: 5, comment: 'العسل بجد ملوش مثيل، ريحة وطعم وقوام أصلي فعلاً. التغليف كمان شيك جداً.', date: '2024-03-10' },
  { id: 'rev2', productId: 'o1', userName: 'سارة فوزي', location: 'الإسكندرية', rating: 5, comment: 'زيت الزيتون ريحته بتجيب لآخر البيت، أول مرة أجرب زيت بكر حقيقي كدة في مصر.', date: '2024-03-12' },
  { id: 'rev3', productId: 'h1', userName: 'أحمد الشناوي', location: 'المنصورة', rating: 4, comment: 'خدمة العملاء محترمة جداً والتوصيل سريع، والمنتج جودته عالية.', date: '2024-03-15' }
];
