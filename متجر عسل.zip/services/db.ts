
import { Product, Order, User, DashboardStats } from '../types';

const ADMIN_CREDENTIALS = {
  email: "mosadghazali123@gmail.com",
  password: "mosadghazali"
};

const DB_KEYS = {
  PRODUCTS: 'gh_v12_products',
  ORDERS: 'gh_v12_orders',
  SESSION: 'gh_v12_session'
};

const get = <T>(key: string, fallback: T): T => {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : fallback;
  } catch {
    return fallback;
  }
};

const set = <T>(key: string, data: T): void => {
  localStorage.setItem(key, JSON.stringify(data));
};

export const db = {
  // Products - Simulation of API calls with async
  getProducts: (): Product[] => get<Product[]>(DB_KEYS.PRODUCTS, []),
  
  saveProduct: async (p: Product): Promise<{success: boolean, product: Product}> => {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const prods = db.getProducts();
    const idx = prods.findIndex(x => x.id === p.id);
    
    let savedProduct = { ...p };
    if (idx > -1) {
      savedProduct.createdAt = prods[idx].createdAt;
      prods[idx] = savedProduct;
    } else {
      savedProduct.createdAt = new Date().toISOString();
      prods.push(savedProduct);
    }
    
    set(DB_KEYS.PRODUCTS, prods);
    return { success: true, product: savedProduct };
  },

  deleteProduct: async (id: string): Promise<boolean> => {
    const prods = db.getProducts().filter(x => x.id !== id);
    set(DB_KEYS.PRODUCTS, prods);
    return true;
  },

  trackAddToCart: (id: string) => {
    const prods = db.getProducts();
    const p = prods.find(x => x.id === id);
    if (p) {
      p.cartAddCount = (p.cartAddCount || 0) + 1;
      set(DB_KEYS.PRODUCTS, prods);
    }
  },

  // Orders
  getOrders: (): Order[] => get<Order[]>(DB_KEYS.ORDERS, []),
  
  createOrder: (order: Order) => {
    const orders = db.getOrders();
    set(DB_KEYS.ORDERS, [order, ...orders]);
    const prods = db.getProducts();
    order.items.forEach(item => {
      const p = prods.find(x => x.id === item.productId);
      if (p) {
        p.purchaseCount = (p.purchaseCount || 0) + item.quantity;
        p.stock -= item.quantity;
      }
    });
    set(DB_KEYS.PRODUCTS, prods);
  },

  updateOrderStatus: (id: string, status: Order['status']) => {
    const orders = db.getOrders();
    const idx = orders.findIndex(x => x.id === id);
    if (idx > -1) {
      orders[idx].status = status;
      set(DB_KEYS.ORDERS, orders);
    }
  },

  // Auth
  login: (email: string, pass: string): User | null => {
    if (email === ADMIN_CREDENTIALS.email && pass === ADMIN_CREDENTIALS.password) {
      const user: User = { id: 'admin-01', name: 'Mosad Ghazali', email, role: 'super_admin' };
      set(DB_KEYS.SESSION, { user, expiry: Date.now() + 86400000 });
      return user;
    }
    return null;
  },

  getSession: (): User | null => {
    const session = get<{ user: User; expiry: number } | null>(DB_KEYS.SESSION, null);
    if (session && Date.now() < session.expiry) return session.user;
    return null;
  },

  logout: () => localStorage.removeItem(DB_KEYS.SESSION),

  getStats: (): DashboardStats => {
    const orders = db.getOrders();
    const prods = db.getProducts();
    return {
      totalRevenue: orders.filter(o => o.status !== 'cancelled').reduce((acc, o) => acc + o.totalPrice, 0),
      totalOrders: orders.length,
      totalProducts: prods.length,
      totalCustomers: new Set(orders.map(o => o.phone)).size,
      cartAnalytics: prods.map(p => ({
        productName: p.name.ar,
        adds: p.cartAddCount || 0,
        sales: p.purchaseCount || 0
      })).sort((a,b) => b.adds - a.adds)
    };
  }
};
