
import { GoogleGenAI } from "@google/genai";

export class GeminiService {
  constructor() {
    // API key is handled via process.env.API_KEY
  }

  // Fix: Create a new GoogleGenAI instance right before making an API call to ensure it always uses the most up-to-date API key
  async transformImage(base64Image: string, prompt: string): Promise<string> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const model = 'gemini-2.5-flash-image';
    
    // The format of base64 usually includes "data:image/png;base64," 
    // We need to strip that if it's there, but inlineData usually expects it stripped.
    const cleanBase64 = base64Image.split(',')[1] || base64Image;

    const response = await ai.models.generateContent({
      model: model,
      contents: {
        parts: [
          {
            inlineData: {
              data: cleanBase64,
              mimeType: 'image/png',
            },
          },
          {
            text: prompt,
          },
        ],
      },
    });

    let resultImageUrl = '';
    
    // Iterate through candidates and parts to find the generated image
    if (response.candidates && response.candidates[0].content.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          const base64EncodeString = part.inlineData.data;
          resultImageUrl = `data:image/png;base64,${base64EncodeString}`;
          break;
        }
      }
    }

    if (!resultImageUrl) {
      throw new Error("Model failed to generate an image response. Please try a different prompt or image.");
    }

    return resultImageUrl;
  }
}

export const geminiService = new GeminiService();
